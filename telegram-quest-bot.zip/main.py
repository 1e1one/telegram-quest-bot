import sqlite3
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters

DB_NAME = 'users.db'

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, points INTEGER DEFAULT 0)''')
    conn.commit()
    conn.close()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    conn.commit()
    conn.close()
    keyboard = [['📜 Выполнить задание', '📈 Мой прогресс'], ['🏆 Лидеры']]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text("Добро пожаловать в квест-бот! Выберите действие:", reply_markup=reply_markup)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    if text == '📜 Выполнить задание':
        c.execute("UPDATE users SET points = points + 10 WHERE user_id = ?", (user_id,))
        conn.commit()
        await update.message.reply_text("✅ Задание выполнено! +10 очков")
    elif text == '📈 Мой прогресс':
        c.execute("SELECT points FROM users WHERE user_id = ?", (user_id,))
        points = c.fetchone()[0]
        await update.message.reply_text(f"У вас {points} очков.")
    elif text == '🏆 Лидеры':
        c.execute("SELECT user_id, points FROM users ORDER BY points DESC LIMIT 5")
        leaders = c.fetchall()
        msg = "🏆 ТОП 5 игроков:
"
        for i, (uid, pts) in enumerate(leaders, start=1):
            msg += f"{i}. ID {uid} — {pts} очков
"
        await update.message.reply_text(msg)
    else:
        await update.message.reply_text("Выберите действие с клавиатуры.")

    conn.close()

def main():
    init_db()
    app = ApplicationBuilder().token("PASTE_YOUR_BOT_TOKEN_HERE").build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling()

if __name__ == '__main__':
    main()
