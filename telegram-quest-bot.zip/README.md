# Telegram Quest Bot

A simple Telegram bot built with Python. Users can:

- Register with /start
- Complete daily quests and earn points
- View their progress
- See leaderboard (top 5 users)

## Features

- SQLite database for storing user data
- Reply keyboard buttons
- Clean and testable structure

## How to Run

1. Replace `PASTE_YOUR_BOT_TOKEN_HERE` in `main.py` with your real bot token from @BotFather.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the bot:

```bash
python main.py
```

Enjoy your first gamified Telegram bot!
